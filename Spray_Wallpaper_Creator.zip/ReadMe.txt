You will need to have steam running and logged into an account that owns rust. 
Run Spray_Wallpaper_Creator.exe
It will use Facepunch.Steamworks.Win32.dll and steam_api.dll to login to steamcmd
They have been bundled with this otherwise you can get the latest versions from your rust client install folder.

If windows is falsely flagging this exe as malicious you will need to add an exception to windows security.
Go to Start > Settings > Update & Security > Windows Security > Virus & threat protection. 
Under Virus & threat protection settings, select Manage settings, 
and then under Exclusions, select Add or remove exclusions.
Select Add an exclusion


How To Use:
Enter a title.
Select Wallpaper if creating wallpaper or leave unchecked to create a spray decal.
Enter Description
Change Permissions.
Click Create Item. (This will create a workshop item on steam and a folder with that workshop id on your computer)

Select Image.
If pngquant.exe is in the same folder as Spray_Wallpaper_Creator compression will be enabled on images.
Images will be edited to correct size and manifest to the workshop ID folder

Click Upload and the workshop ID folder will be uploaded from your computer to steams workshop.
You can hand edit the manifest and images before clicking upload if you want.

Once done close program.
You can edit a existing workshop item if you have a folder with the same name.
Click edit and enter that ID.
If the images are missing it will allow you to select new ones.